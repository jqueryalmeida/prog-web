<?php
	
	//COLOCAR OS DADOS DO SERVIÇO DE EMAIL DE SUA HOSPEDAGEM, PARA PODER ENVIAR E-MAILS PELA APLICAÇÃO

    const MAIL_HOST     = 'smtp1.example.com';
    const MAIL_USERNAME = 'user@example.com';
    const MAIL_PASSWORD = 'secret';
    const MAIL_PORT     = 587;
